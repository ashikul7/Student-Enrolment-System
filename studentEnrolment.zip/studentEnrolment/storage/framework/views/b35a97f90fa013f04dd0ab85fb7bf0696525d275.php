<?php $__env->startSection("mainContain"); ?>
<div class="container">
	<h2>Student Details</h2>

	<img src ="" width="300"/>

	<table>
		<?php $__currentLoopData = $student_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td>Student Name</td><td>:</td><td class="text-primary"><?php echo e($data->name); ?></td>
		</tr>
		<tr>
			<td>Student Roll</td><td>:</td><td><?php echo e($data->roll); ?></td>
		</tr>
		<tr>
			<td>Student Department </td><td>:</td><td><?php echo e($data->department); ?></td>
		</tr>
		<tr>
			<td>Student Phone</td><td>:</td><td><?php echo e($data->phone); ?></td>
		</tr>
		<tr>
			<td>Student Email</td><td>:</td><td><?php echo e($data->email); ?></td>
		</tr>
		<tr>
			<td> Father Name</td><td>:</td><td><?php echo e($data->father_name); ?></td>
		</tr>
		<tr>
			<td>Mother Name</td><td>:</td><td><?php echo e($data->mother_name); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("include.side", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>