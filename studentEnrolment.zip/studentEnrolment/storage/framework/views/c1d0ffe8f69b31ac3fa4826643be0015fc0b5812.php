<?php $__env->startSection("mainContain"); ?>
	<div class="container">
	  <h2>Information of Student</h2>
	  <p>Student showen from  database :</p>            
	  <table class="table">
	    <thead>
	      <tr>
	        <th>Student Name</th>
	        <th>Student Roll</th>
	        <th>Phone Number</th>
	        <th>Department</th>
	        <th>Student Email</th>
	        <th>Action</th>
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $__currentLoopData = $allStudent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      <tr>
	        <td><?php echo e($data->name); ?></td>
	        <td><?php echo e($data->roll); ?></td>
	        <td><?php echo e($data->phone); ?></td>
	        <td>
	        	<?php if($data->department==1): ?>
	        		Accounting
	        	<?php elseif($data->department==2): ?> 
	        		Computer Science
	        	<?php elseif($data->department==3): ?>
	        		Mathematic
	        	<?php endif; ?>
	        </td>
	        <td><?php echo e($data->email); ?></td>
	        <td><a href="<?php echo e(url('/view-student/'.$data->id)); ?>">View</a> | 
	        	<a href="<?php echo e(url('/edit-student/'. $data->id)); ?>">Edit</a> | 
	        	<a href="<?php echo e(url('/delete-student/'.$data->id)); ?>" onclick="return confirm('Are you sure to delete the student ?')">Delete</a></td>
	      </tr>
	      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </tbody>

	  </table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("include.side", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>