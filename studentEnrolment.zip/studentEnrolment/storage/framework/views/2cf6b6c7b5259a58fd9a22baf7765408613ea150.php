<?php $__env->startSection("mainContain"); ?>
<div class="container">

	<h2>Student Details</h2>
	<li>Student Image</li>
	

	<table class="table">
	    <thead>
	      <tr>
	        <th>Student Name</th>
	        <th>Student Roll</th>
	        <th>Department</th>
	        <th>Student Phone</th>
	        <th>Student Email</th>
	        <th>Father Name</th>
	        <th>Mother Name</th>
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $__currentLoopData = $student_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	<img src ="<?php echo e(asset($data->image)); ?>" width="300"/>
	      <tr>
	        <td><?php echo e($data->name); ?></td>
	        <td><?php echo e($data->roll); ?></td>
	        <td>
	        	<?php if($data->department==1): ?>
	        		Accounting
	        	<?php elseif($data->department==2): ?> 
	        		Computer Science
	        	<?php elseif($data->department==3): ?>
	        		Mathematic
	        	<?php endif; ?>
	        </td>
	        <td><?php echo e($data->phone); ?></td>
	        <td><?php echo e($data->email); ?></td>
	        <td><?php echo e($data->father_name); ?></td>
	        <td><?php echo e($data->mother_name); ?></td>
	      </tr>
	      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </tbody>

	  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("include.side", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>