<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddStudent extends Model
{
    //
}
